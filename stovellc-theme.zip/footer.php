<footer id="footer">
    <p>STOVE LLC, Copyright <?php echo date('Y'); ?> ©</p>
    <a href="#">Back To Top ↑</a>
    <!-- Add scroll animation done -->
</footer>

<!-- Link to JavaScript file -->
<script src="<?php echo get_template_directory_uri(); ?>/assets/js/script.js"></script>

<?php wp_footer(); ?>
</body>
</html>
